from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import py_compile
import shutil
import sys
from datetime import datetime
from pathlib import Path


PATCH_NAME = "singshirpg-ui-v7"
PAYLOAD_DIRNAME = "singshirpg_ui_v7_payload"
STATE_FILENAME = ".singshirpg_ui_v7_state.json"

FILES = {
    "myhome.py": {
        "before": "354c3528b53916ac556a9a9e42cf3c08124a0da710f63e97f0f4080f66d30eb9",
        "after": "f6a2a89e55508d5a0c19223a55f2fa2d91a93435d477f476d0e8bbbb0c8f74fc",
    },
    "rpg_commands.py": {
        "before": "5c363edf4957958edc7706f8b73d7a23972b0d8cdcdb7d97aabf63085a1f8021",
        "after": "de5b443290f9c62f91ef6c742ef8650c608672a0cda9ab4340b97643d7b3d84a",
    },
    "life_overhaul_v5.py": {
        "before": "e2a7e1f1816402070897d8357e57b8646afc07db1d4463c507f0d926d0506818",
        "after": "cf114a06069a421f5d48a8dc74ce4563f9f744ecbeb291e507c1fe2a579b8b3b",
    },
    "life_system.py": {
        "before": "954152ea700d970e2b421a996ca5edc70f51c460ccecc357453fb5f75b1a877b",
        "after": "fe68bce08df6bec49edb476a28e66668a16528e7402d1440b1cdc61bd8f0103a",
    },
    "cooking_system_v6.py": {
        "before": "c5ffd501ff1c2f6a1323cc805d0d6997495c50721693a203654ac7760d17aef6",
        "after": "ab2731f6d3eaa5e53ede2e3ae193ed98ad97bc102ca303194ac51697492d941c",
    },
    "navigation_v7.py": {
        "before": None,
        "after": "0473e1f673e2184acf6e8c78e1204670140207c18e936ed57e2e6129b64e269c",
    },
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def resolve_target(argument: str | None) -> Path:
    if argument:
        return Path(argument).expanduser().resolve()
    script_dir = Path(__file__).resolve().parent
    if (script_dir / "main.py").is_file():
        return script_dir
    current = Path.cwd().resolve()
    if (current / "main.py").is_file():
        return current
    raise SystemExit(
        "봇 저장소를 찾지 못했습니다. 압축을 H:\\디코봇에 풀거나 "
        "--target \"H:\\디코봇\"을 지정하세요."
    )


def payload_root() -> Path:
    root = Path(__file__).resolve().parent / PAYLOAD_DIRNAME
    if not root.is_dir():
        raise SystemExit(f"패치 payload 폴더가 없습니다: {root}")
    return root


def validate_payload(root: Path) -> None:
    for name, hashes in FILES.items():
        source = root / name
        if not source.is_file():
            raise SystemExit(f"패치 파일이 누락되었습니다: {source}")
        actual = sha256(source)
        if actual != hashes["after"]:
            raise SystemExit(f"패치 파일 무결성 오류: {name}")
        py_compile.compile(str(source), doraise=True)

    source = (root / "rpg_commands.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    command_names = []
    routes = {}
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for decorator in node.decorator_list:
            if not isinstance(decorator, ast.Call):
                continue
            if not isinstance(decorator.func, ast.Attribute) or decorator.func.attr != "command":
                continue
            for keyword in decorator.keywords:
                if keyword.arg == "name" and isinstance(keyword.value, ast.Constant):
                    command_names.append(keyword.value.value)
                    routes[keyword.value.value] = ast.get_source_segment(source, node) or ""
    if command_names.count("마이홈") != 1 or command_names.count("생활") != 1:
        raise SystemExit("/마이홈 또는 /생활 명령 정의가 중복된 payload입니다.")
    if "MyHomeView" not in routes["마이홈"] or "LifeHubView" not in routes["생활"]:
        raise SystemExit("명령 라우팅 검증에 실패했습니다.")


def status_for(target: Path, name: str, hashes: dict) -> str:
    path = target / name
    if not path.exists():
        return "READY" if hashes["before"] is None else "MISSING"
    actual = sha256(path)
    if actual == hashes["after"]:
        return "ALREADY"
    if hashes["before"] is not None and actual == hashes["before"]:
        return "READY"
    return "CONFLICT"


def inspect(target: Path) -> dict[str, str]:
    return {
        name: status_for(target, name, hashes)
        for name, hashes in FILES.items()
    }


def print_status(target: Path, statuses: dict[str, str]) -> None:
    print(f"[{PATCH_NAME}] 대상: {target}")
    for name, state in statuses.items():
        print(f"  {state:8} {name}")


def ensure_target(target: Path) -> None:
    for required in ("main.py", "rpg_commands.py", "myhome.py"):
        if not (target / required).is_file():
            raise SystemExit(f"봇 저장소 파일이 없습니다: {target / required}")


def atomic_copy(source: Path, destination: Path) -> None:
    temporary = destination.with_name(destination.name + ".ui_v7.tmp")
    shutil.copy2(source, temporary)
    os.replace(temporary, destination)


def rollback(target: Path, records: list[dict]) -> None:
    for record in reversed(records):
        destination = target / record["name"]
        if record["existed"]:
            atomic_copy(Path(record["backup"]), destination)
        elif destination.exists():
            destination.unlink()


def apply_patch(target: Path, payload: Path) -> None:
    statuses = inspect(target)
    print_status(target, statuses)
    blocked = [name for name, state in statuses.items() if state in {"MISSING", "CONFLICT"}]
    if blocked:
        raise SystemExit(
            "현재 파일이 이 패치가 검사한 v6 상태와 다릅니다. 적용하지 않았습니다: "
            + ", ".join(blocked)
        )
    pending = [name for name, state in statuses.items() if state == "READY"]
    if not pending:
        print("이미 모두 적용되어 있습니다.")
        return

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = target / ".patch_backups" / f"ui_v7_{stamp}"
    backup_dir.mkdir(parents=True, exist_ok=False)
    records = []
    try:
        for name in pending:
            destination = target / name
            existed = destination.exists()
            backup = backup_dir / name
            if existed:
                shutil.copy2(destination, backup)
            records.append({
                "name": name,
                "existed": existed,
                "backup": str(backup),
            })

        for name in pending:
            atomic_copy(payload / name, target / name)

        for name, hashes in FILES.items():
            if sha256(target / name) != hashes["after"]:
                raise RuntimeError(f"적용 후 해시 검증 실패: {name}")
            py_compile.compile(str(target / name), doraise=True)

        state = {
            "patch": PATCH_NAME,
            "applied_at": datetime.now().isoformat(timespec="seconds"),
            "backup_dir": str(backup_dir),
            "records": records,
        }
        (target / STATE_FILENAME).write_text(
            json.dumps(state, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception:
        rollback(target, records)
        raise
    print("적용과 문법 검사가 완료되었습니다. 봇을 완전히 재시작하세요.")


def revert_patch(target: Path) -> None:
    state_path = target / STATE_FILENAME
    if not state_path.is_file():
        raise SystemExit("이 패치의 복구 기록이 없습니다.")
    state = json.loads(state_path.read_text(encoding="utf-8"))
    if state.get("patch") != PATCH_NAME:
        raise SystemExit("복구 기록의 패치 이름이 일치하지 않습니다.")

    changed = [
        name for name, hashes in FILES.items()
        if not (target / name).is_file() or sha256(target / name) != hashes["after"]
    ]
    if changed:
        raise SystemExit(
            "패치 적용 후 파일이 다시 수정되어 안전하게 되돌릴 수 없습니다: "
            + ", ".join(changed)
        )
    rollback(target, state["records"])
    state_path.unlink()
    print("패치 적용 전 상태로 되돌렸습니다.")


def main() -> None:
    parser = argparse.ArgumentParser(description="SingshiRPG 마이홈·생활 UI v7 패치")
    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument("--check", action="store_true", help="현재 적용 가능 여부만 검사")
    actions.add_argument("--apply", action="store_true", help="검사 후 패치 적용")
    actions.add_argument("--revert", action="store_true", help="이 패치가 만든 백업으로 복구")
    parser.add_argument("--target", help="봇 저장소 경로. 예: H:\\디코봇")
    args = parser.parse_args()

    target = resolve_target(args.target)
    ensure_target(target)
    payload = payload_root()
    validate_payload(payload)

    if args.check:
        statuses = inspect(target)
        print_status(target, statuses)
        if any(state in {"MISSING", "CONFLICT"} for state in statuses.values()):
            raise SystemExit(2)
        print("검사 완료: 안전하게 적용할 수 있습니다.")
    elif args.apply:
        apply_patch(target, payload)
    else:
        revert_patch(target)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        raise
