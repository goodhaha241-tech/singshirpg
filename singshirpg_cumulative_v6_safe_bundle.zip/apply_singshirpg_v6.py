from __future__ import annotations

import argparse
import compileall
import hashlib
import json
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path


BUNDLE_ROOT = Path(__file__).resolve().parent
PAYLOAD_ROOT = BUNDLE_ROOT / "payload"
MANIFEST_PATH = BUNDLE_ROOT / "manifest.json"
BACKUP_ROOT_NAME = ".singshirpg-v6-backups"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_manifest() -> dict:
    with MANIFEST_PATH.open("r", encoding="utf-8") as file:
        return json.load(file)


def classify(repo: Path, manifest: dict):
    rows = []
    for entry in manifest["files"]:
        target = repo / entry["path"]
        payload = PAYLOAD_ROOT / entry["path"]
        if not payload.is_file() or sha256(payload) != entry["payload_sha256"]:
            rows.append((entry, "invalid-payload"))
            continue
        if not target.exists():
            status = "pending" if entry["original_sha256"] is None else "missing"
        else:
            current = sha256(target)
            if current == entry["payload_sha256"]:
                status = "applied"
            elif entry["original_sha256"] and current == entry["original_sha256"]:
                status = "pending"
            else:
                status = "mismatch"
        rows.append((entry, status))
    return rows


def print_status(rows):
    labels = {
        "pending": "적용 대기",
        "applied": "이미 적용",
        "mismatch": "충돌",
        "missing": "원본 누락",
        "invalid-payload": "묶음 손상",
    }
    for entry, status in rows:
        print(f"[{labels[status]}] {entry['path']}")


def assert_safe(rows):
    blockers = [(entry, status) for entry, status in rows if status not in {"pending", "applied"}]
    if blockers:
        print("\n안전 검사에서 충돌을 발견했습니다. 어떤 파일도 수정하지 않았습니다.")
        print_status(blockers)
        raise SystemExit(2)


def atomic_copy(source: Path, target: Path):
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.v6-tmp")
    shutil.copy2(source, temporary)
    os.replace(temporary, target)


def create_backup(repo: Path, rows):
    backup_root = repo / BACKUP_ROOT_NAME
    backup_root.mkdir(exist_ok=True)
    backup = backup_root / datetime.now().strftime("%Y%m%d-%H%M%S")
    backup.mkdir()
    record = {"created_at": datetime.now().isoformat(), "files": []}
    for entry, status in rows:
        if status != "pending":
            continue
        target = repo / entry["path"]
        existed = target.exists()
        if existed:
            destination = backup / entry["path"]
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, destination)
        record["files"].append({"path": entry["path"], "existed": existed})
    with (backup / "backup.json").open("w", encoding="utf-8") as file:
        json.dump(record, file, ensure_ascii=False, indent=2)
    return backup


def restore_backup(repo: Path, backup: Path):
    with (backup / "backup.json").open("r", encoding="utf-8") as file:
        record = json.load(file)
    for entry in record["files"]:
        target = repo / entry["path"]
        if entry["existed"]:
            atomic_copy(backup / entry["path"], target)
        elif target.exists():
            target.unlink()


def apply(repo: Path, manifest: dict):
    rows = classify(repo, manifest)
    print_status(rows)
    assert_safe(rows)
    pending = [(entry, status) for entry, status in rows if status == "pending"]
    if not pending:
        print("\n모든 v6 파일이 이미 적용되어 있습니다.")
        return
    backup = create_backup(repo, pending)
    try:
        for entry, _ in pending:
            atomic_copy(PAYLOAD_ROOT / entry["path"], repo / entry["path"])
        if not compileall.compile_dir(str(repo), quiet=1, force=True):
            raise RuntimeError("Python 문법 검사 실패")
    except Exception:
        restore_backup(repo, backup)
        print(f"\n적용에 실패하여 백업에서 복구했습니다: {backup}")
        raise
    print(f"\n적용 완료. 백업: {backup}")
    print("봇을 완전히 재시작하면 DB 보강과 슬래시 명령 동기화가 자동 실행됩니다.")


def revert(repo: Path):
    backup_root = repo / BACKUP_ROOT_NAME
    backups = sorted(
        (path for path in backup_root.iterdir() if (path / "backup.json").is_file()),
        reverse=True,
    ) if backup_root.is_dir() else []
    if not backups:
        raise SystemExit("복구할 v6 백업이 없습니다.")
    backup = backups[0]
    restore_backup(repo, backup)
    if not compileall.compile_dir(str(repo), quiet=1, force=True):
        raise SystemExit("복구 후 문법 검사에 실패했습니다. 백업 내용을 직접 확인하세요.")
    print(f"복구 완료: {backup}")


def main():
    parser = argparse.ArgumentParser(description="싱시 RPG 누적 v6 안전 적용기")
    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument("--check", action="store_true", help="수정 없이 적용 가능 여부만 검사")
    actions.add_argument("--apply", action="store_true", help="백업 후 v6 적용")
    actions.add_argument("--revert", action="store_true", help="가장 최근 v6 백업으로 복구")
    parser.add_argument("--repo", default=".", help="봇 저장소 경로(기본: 현재 폴더)")
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    if not (repo / "main.py").is_file() or not (repo / "rpg_commands.py").is_file():
        raise SystemExit(f"봇 저장소 루트가 아닙니다: {repo}")

    if args.revert:
        revert(repo)
        return
    manifest = load_manifest()
    rows = classify(repo, manifest)
    print_status(rows)
    assert_safe(rows)
    if args.check:
        pending = sum(status == "pending" for _, status in rows)
        applied = sum(status == "applied" for _, status in rows)
        print(f"\n안전 검사 통과: 적용 대기 {pending}개, 이미 적용 {applied}개")
        return
    apply(repo, manifest)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
