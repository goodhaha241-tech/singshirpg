"""Offline v6 integration checks. This file is not required by the bot runtime."""
from __future__ import annotations

import ast
import asyncio
from pathlib import Path
from unittest.mock import patch

from artifact_overhaul_v5 import dismantle_artifact, reroll_artifact, toggle_lock
from cooking_system_v6 import (
    DAILY_DELIVERY_TARGET,
    RECIPES,
    cook,
    deliver_food,
    ensure_cooking_data,
)
from data_manager import _get_new_user_data
from gem_manager import equip_gem, unequip_gem
from life_overhaul_v5 import grant_starter_supplies
from life_system import (
    CROPS,
    FISH_SPECIES,
    SEED_ITEMS,
    FINGERLING_ITEMS,
    STONE_GEMS,
    claim_crop,
    claim_fish,
    draw_crafting_tool,
    ensure_life_data,
    perform_craft_action,
    start_crop,
    start_fish_farm,
    start_gem_crafting,
)
from progression_system_v6 import claim_attendance, ensure_progression


ROOT = Path.cwd()


def check_commands():
    tree = ast.parse((ROOT / "rpg_commands.py").read_text(encoding="utf-8"))
    names = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for deco in node.decorator_list:
            if not (
                isinstance(deco, ast.Call)
                and isinstance(deco.func, ast.Attribute)
                and deco.func.attr == "command"
            ):
                continue
            for keyword in deco.keywords:
                if keyword.arg == "name" and isinstance(keyword.value, ast.Constant):
                    names.append(keyword.value.value)
    assert names.count("마이홈") == 1
    assert names.count("생활") == 1
    assert names.count("길드") == 1


def check_schema_and_sql():
    schema = (ROOT / "schema.sql").read_text(encoding="utf-8")
    for required in (
        "total_turns BIGINT",
        "CREATE TABLE IF NOT EXISTS user_life_data",
        "gems JSON",
        "metadata JSON",
        "CREATE TABLE IF NOT EXISTS guild_members",
    ):
        assert required in schema, required

    source = (ROOT / "data_manager.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    counts = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Await) or not isinstance(node.value, ast.Call):
            continue
        call = node.value
        if not call.args or not isinstance(call.args[0], ast.Constant):
            continue
        sql = call.args[0].value
        if isinstance(sql, str) and "INSERT INTO users" in sql:
            assert sql.count("%s") == 31
            assert isinstance(call.args[1], ast.Tuple)
            assert len(call.args[1].elts) == 31
        if isinstance(sql, str) and "INSERT INTO artifacts" in sql:
            counts.append(sql.count("%s"))
    assert 13 in counts


def check_life_loop(user):
    life = ensure_life_data(user)
    grant_starter_supplies(user)
    crop = next(iter(CROPS))
    fish = next(iter(FISH_SPECIES))
    user["inventory"][SEED_ITEMS[crop]] = 1
    user["inventory"][FINGERLING_ITEMS[fish]] = 1

    ok, _ = start_crop(user, crop, 0)
    assert ok and user["inventory"][SEED_ITEMS[crop]] == 0
    life["vegetable_garden"]["plot"]["complete"] = True
    ok, _ = claim_crop(user)
    assert ok and user["inventory"][crop] >= 1

    ok, _ = start_fish_farm(user, fish, 0)
    assert ok and user["inventory"][FINGERLING_ITEMS[fish]] == 0
    life["fish_farm"]["tank"]["complete"] = True
    ok, _ = claim_fish(user)
    assert ok and user["inventory"][fish] >= 1


def check_gem_loop(user):
    life = ensure_life_data(user)
    stone = next(iter(STONE_GEMS))
    life["stones"][stone] = 1
    ok, _ = start_gem_crafting(user, stone, 0, 0, [])
    assert ok
    with patch("life_system.random.randint", return_value=1):
        for action in ["heat", "heat", "shape"] + ["enchant"] * 17:
            ok, _, result = perform_craft_action(user, action)
            assert ok
    assert result and result["star"] >= 2
    assert life["gem_crafting"] is None

    tool_name = draw_crafting_tool(user)["name"]
    with patch("life_system._choose_tool_name", return_value=tool_name):
        result = draw_crafting_tool(user)
    assert result["result"] == "breakthrough"
    assert life["tools"][tool_name] == 1

    artifact = {
        "id": "artifact-test",
        "name": "테스트 아티팩트",
        "rank": 3,
        "level": 0,
        "special": life["gems"][0].get("target_special"),
        "stats": {"attack": 1},
        "gems": [],
        "metadata": {},
        "equipped_char_index": -1,
    }
    user["artifacts"].append(artifact)
    gem_id = result_gem = life["gems"][0]["id"]
    ok, _ = equip_gem(user, artifact, gem_id, 0)
    assert ok and artifact["gems"][0]["id"] == result_gem
    ok, _ = unequip_gem(artifact, 0)
    assert ok


def check_cooking_and_artifacts(user):
    cooking = ensure_cooking_data(user)
    recipe = cooking["unlocked_recipes"][0]
    for ingredient, amount in RECIPES[recipe]["ingredients"].items():
        user["inventory"][ingredient] = amount * 10
    with patch("cooking_system_v6.random.choices", return_value=["걸작"]):
        ok, _, qualities = cook(user, recipe, 10)
    assert ok and qualities == ["걸작"] * 10
    food_key = f"걸작 {recipe}"
    day = "2026-07-26"
    ok, _ = deliver_food(user, food_key, 2, day)
    assert ok and cooking["delivery"]["points"] >= DAILY_DELIVERY_TARGET
    assert user["inventory"]["순수한 희망"] >= 1

    artifact = user["artifacts"][0]
    old_money = user["money"] = 1_000_000
    ok, _ = reroll_artifact(user, artifact["id"])
    assert ok and user["money"] < old_money
    assert toggle_lock(artifact) is True
    ok, _ = dismantle_artifact(user, artifact["id"])
    assert not ok
    assert toggle_lock(artifact) is False
    ok, _ = dismantle_artifact(user, artifact["id"])
    assert ok and user["inventory"]["유물 가루"] > 0


async def main():
    user = await _get_new_user_data("테스터")
    ensure_progression(user)
    check_commands()
    check_schema_and_sql()
    check_life_loop(user)
    check_gem_loop(user)
    check_cooking_and_artifacts(user)
    ok, _ = claim_attendance(user)
    assert ok
    ok, _ = claim_attendance(user)
    assert not ok
    print("v6 smoke tests: OK")


if __name__ == "__main__":
    asyncio.run(main())
