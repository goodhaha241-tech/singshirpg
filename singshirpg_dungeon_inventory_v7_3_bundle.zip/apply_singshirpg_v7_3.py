from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import py_compile
import shutil
import sys
import tempfile
from datetime import datetime
from pathlib import Path


PATCH_NAME = "dungeon-inventory-v7.3"
BASE_HASHES = {
    "life_system.py": "0a532cb121546ea14b680f4abc22a9e458d031ddd98f2e46ee0f9e32a1216c04",
    "myhome.py": "ce54502637e7a483156dabaa904c2a5e85baf01db8039fc999e873bcb72953eb",
    "gem_manager.py": "d0de1864e344b7312912dbaa731aaf1f6dd9c60ef78e45d67b81587021a391f7",
    "artifact_overhaul_v5.py": "862b37d2c7ab1d78aafad72f81a9d05452da50db2c40f8c8d509a8786ddedf67",
    "life_overhaul_v5.py": "cf114a06069a421f5d48a8dc74ce4563f9f744ecbeb291e507c1fe2a579b8b3b",
    "subjugation.py": "ca52159f4b13fe58ada3078ade90049f1dd022a05e639181f0dc38ec58cd2712",
    "battle.py": "cec2cc64464cbfd72a4ad144384047ff8acb3a033d96411b351b8ea11900ceea",
    "artifact_manager.py": "57d83f066981ddcc5de913fff1a2d81441ddde2f6d83c26e88f0fdeca8919a39",
}
UPGRADE_HASHES = {
    # 바로 전 v7.3 묶음을 이미 적용한 저장소도 실제 수치 표시판으로 갱신할 수 있다.
    "gem_manager.py": {
        "28d7b646a51f7164a611352b04786207f6b4efcd862800c778b68a8a5cfd648c",
    },
    "artifact_overhaul_v5.py": {
        "031dccfc0150047b648357343263fa7a6ec8081a698a8f8f9b7d9c74a5f4b0c3",
    },
}
DESIRED_HASHES = {
    "life_system.py": "2fc4a0d80d84f605fa693d1aa9b1c3f0d70b63ea5a1734bee671c14e4a18c430",
    "myhome.py": "640c5981f3b8530f023ed6bd3ab536aed0c53b6843a85cad78b5c6bb7acfa331",
    "gem_manager.py": "ace8616f012773f92d339ee04109d0fe792243622352342589c3df07ea38eb45",
    "artifact_overhaul_v5.py": "a877b222f98fc2533437191fefe6fb904ba7b14288ce1828b92effe77a103956",
    "life_overhaul_v5.py": "6c8f751b241160864f445cef9fe3cbdb14c5c4e708691fdb203ba5e77e3668b7",
    "subjugation.py": "8ed49fcb9404c8896a0484d5834390fd1a2a760c530a70ef2dbbcb38b873e494",
    "battle.py": "6de91b45ed6c0317858b482f7de9aa42813f8a392bd31161eeeaff98501f16c0",
    "artifact_manager.py": "90670f4249fb10560ca58015173b6190139f7e957d1986a568b4acf6813174bd",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_root(value: str | None) -> Path:
    candidates = []
    if value:
        candidates.append(Path(value))
    candidates.extend((Path.cwd(), Path(__file__).resolve().parent))
    for candidate in candidates:
        candidate = candidate.resolve()
        if (candidate / "main.py").is_file() and (candidate / "rpg_commands.py").is_file():
            return candidate
    raise SystemExit(
        "저장소 루트를 찾지 못했습니다. H:\\디코봇에서 실행하거나 "
        "--root \"H:\\디코봇\"을 지정하세요."
    )


def payload_dir() -> Path:
    path = Path(__file__).resolve().parent / "payload"
    if not path.is_dir():
        raise SystemExit(f"payload 폴더가 없습니다: {path}")
    return path


def verify_payload() -> list[str]:
    errors = []
    for name, expected in DESIRED_HASHES.items():
        source = payload_dir() / name
        if not source.is_file():
            errors.append(f"{name}: payload 누락")
        elif sha256(source) != expected:
            errors.append(f"{name}: payload 해시 불일치")
        else:
            try:
                py_compile.compile(str(source), doraise=True)
            except py_compile.PyCompileError as error:
                errors.append(f"{name}: 문법 검사 실패: {error.msg}")
    return errors


def inspect(root: Path):
    rows = []
    for name in BASE_HASHES:
        target = root / name
        if not target.is_file():
            status = "missing"
            current = None
        else:
            current = sha256(target)
            if current == DESIRED_HASHES[name]:
                status = "applied"
            elif current == BASE_HASHES[name] or current in UPGRADE_HASHES.get(name, set()):
                status = "ready"
            else:
                status = "conflict"
        rows.append((name, status, current))
    return rows


def print_status(root: Path) -> bool:
    payload_errors = verify_payload()
    if payload_errors:
        print("[payload 오류]")
        for error in payload_errors:
            print(f"  - {error}")
        return False
    print(f"저장소: {root}")
    okay = True
    for name, status, current in inspect(root):
        labels = {
            "ready": "적용 가능",
            "applied": "이미 적용됨",
            "missing": "파일 없음",
            "conflict": "충돌",
        }
        print(f"  {name:<28} {labels[status]}")
        if status in {"missing", "conflict"}:
            okay = False
            if current:
                print(f"    현재 SHA256: {current}")
                print(f"    예상 SHA256: {BASE_HASHES[name]}")
                for allowed in sorted(UPGRADE_HASHES.get(name, set())):
                    print(f"    허용 업그레이드 SHA256: {allowed}")
    return okay


def show_diff(root: Path) -> int:
    if not print_status(root):
        print("\n충돌 파일이 있어 미리보기를 중단했습니다.")
        return 2
    for name, status, _ in inspect(root):
        if status == "applied":
            continue
        old = (root / name).read_text(encoding="utf-8").splitlines(keepends=True)
        new = (payload_dir() / name).read_text(encoding="utf-8").splitlines(keepends=True)
        sys.stdout.writelines(difflib.unified_diff(
            old,
            new,
            fromfile=f"a/{name}",
            tofile=f"b/{name}",
        ))
    return 0


def apply(root: Path) -> int:
    if not print_status(root):
        print("\n아무 파일도 수정하지 않았습니다.")
        return 2
    pending = [name for name, status, _ in inspect(root) if status == "ready"]
    if not pending:
        print("\n모든 대상 파일이 이미 v7.3 상태입니다.")
        return 0

    backup_root = root / ".singshirpg_patch_backups" / PATCH_NAME
    backup_dir = backup_root / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_dir.mkdir(parents=True, exist_ok=False)
    for name in pending:
        shutil.copy2(root / name, backup_dir / name)

    state = {
        "patch": PATCH_NAME,
        "root": str(root),
        "backup_dir": str(backup_dir),
        "files": pending,
        "applied_hashes": {name: DESIRED_HASHES[name] for name in pending},
    }
    (backup_root / "latest.json").write_text(
        json.dumps(state, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    written = []
    try:
        for name in pending:
            target = root / name
            source = payload_dir() / name
            with tempfile.NamedTemporaryFile(
                mode="wb",
                delete=False,
                dir=target.parent,
                prefix=f".{name}.",
                suffix=".tmp",
            ) as handle:
                handle.write(source.read_bytes())
                temp_path = Path(handle.name)
            temp_path.replace(target)
            written.append(name)
        for name in pending:
            py_compile.compile(str(root / name), doraise=True)
            if sha256(root / name) != DESIRED_HASHES[name]:
                raise RuntimeError(f"{name} 적용 후 해시 불일치")
    except Exception as error:
        for name in written:
            shutil.copy2(backup_dir / name, root / name)
        print(f"\n적용 중 오류가 발생해 원본을 복원했습니다: {error}")
        return 3

    print(f"\n{len(pending)}개 파일에 v7.3 패치를 적용했습니다.")
    print(f"백업: {backup_dir}")
    print("봇을 완전히 재시작한 뒤 던전 이어하기와 세 관리 화면을 확인하세요.")
    return 0


def revert(root: Path) -> int:
    state_path = root / ".singshirpg_patch_backups" / PATCH_NAME / "latest.json"
    if not state_path.is_file():
        print("되돌릴 백업 기록이 없습니다.")
        return 2
    state = json.loads(state_path.read_text(encoding="utf-8"))
    backup_dir = Path(state["backup_dir"])
    conflicts = []
    for name in state["files"]:
        target = root / name
        if not target.is_file() or sha256(target) != state["applied_hashes"][name]:
            conflicts.append(name)
    if conflicts:
        print("적용 이후 다시 수정된 파일이 있어 되돌리기를 중단했습니다:")
        for name in conflicts:
            print(f"  - {name}")
        print("아무 파일도 수정하지 않았습니다.")
        return 2
    for name in state["files"]:
        shutil.copy2(backup_dir / name, root / name)
    print(f"{len(state['files'])}개 파일을 적용 전 상태로 복원했습니다.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="신시 RPG 던전·장비 관리 v7.3 패치")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--check", action="store_true", help="적용 가능 여부만 검사")
    action.add_argument("--diff", action="store_true", help="변경 미리보기 출력")
    action.add_argument("--apply", action="store_true", help="검증 후 패치 적용")
    action.add_argument("--revert", action="store_true", help="최근 적용 백업으로 복원")
    parser.add_argument("--root", help="봇 저장소 루트. 기본값은 현재 폴더")
    args = parser.parse_args()
    root = resolve_root(args.root)
    if args.check:
        return 0 if print_status(root) else 2
    if args.diff:
        return show_diff(root)
    if args.apply:
        return apply(root)
    return revert(root)


if __name__ == "__main__":
    raise SystemExit(main())
