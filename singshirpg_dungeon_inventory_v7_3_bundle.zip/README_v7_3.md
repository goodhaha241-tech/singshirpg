# 던전·장비 관리 v7.3 적용 안내

이 패치는 현재 `H:\디코봇`에 적용된 길드·PVP 안정화 v7.2 위에 적용합니다.
DB 테이블이나 컬럼은 추가하지 않으며, 기존 아티팩트·젬·던전 저장 데이터는 보존합니다.
바로 전 v7.3 묶음을 이미 적용했다면 나머지는 유지하고 젬 표시 관련 2개 파일만 갱신합니다.

## 적용 전

봇을 완전히 종료한 뒤 압축 파일의 내용을 `H:\디코봇`에 풉니다.
`apply_singshirpg_v7_3.py`와 `payload` 폴더가 함께 있어야 합니다.

## 적용

PowerShell 또는 명령 프롬프트에서:

```powershell
Set-Location 'H:\디코봇'
C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe apply_singshirpg_v7_3.py --check
C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe apply_singshirpg_v7_3.py --diff > v7_3.preview.diff
C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe apply_singshirpg_v7_3.py --apply
C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -m compileall -q .
```

`--check`에서 충돌이 나오면 `--apply`하지 마세요. 해당 파일은 현재 저장소와
이 패치가 검사한 기준본이 다르므로 수동 병합이 필요합니다.

## 적용 후 확인

1. `/던전`에서 새 탐사를 시작하고 선택 버튼을 빠르게 두 번 눌러도 한 층만 진행되는지 확인합니다.
2. 전투 화면을 닫았다가 `이어하기`를 눌렀을 때 저장된 선택지 또는 중단된 전투가 이어지는지 확인합니다.
3. `/마이홈 → 정비 → 아티팩트 관리`에서 분류, 8개 페이지, 장착자 표시를 확인합니다.
4. `/생활 → 세공 도구 관리`에서 행동 종류별 분류와 8개 페이지를 확인합니다.
5. `/생활 → 젬 관리`에서 젬 분류와 상세 효과를 확인합니다.
6. 젬의 `아티팩트에 장착`에서 아티팩트 분류, 장착자, 8개 페이지, 소켓 선택을 확인합니다.
7. 젬 상세와 장착 화면에서 `현재 실제 적용 효과`가 이름·성급·수치에 맞게 표시되는지 확인합니다.
8. 아티팩트 상세의 각 소켓에도 장착 젬의 실제 보정 수치가 함께 표시되는지 확인합니다.

`보조 수치` 또는 아직 전투 호출 지점이 없는 효과는 적용 중인 것처럼 꾸미지 않고
`미연결`로 표시합니다. 이는 저장된 세공 결과를 삭제하거나 변경하지 않으며,
후속 효과 연결 패치에서 그대로 사용할 수 있습니다.

## 되돌리기

```powershell
C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe apply_singshirpg_v7_3.py --revert
```

적용 후 대상 파일을 다시 수정했다면 안전을 위해 자동 되돌리기가 중단됩니다.
