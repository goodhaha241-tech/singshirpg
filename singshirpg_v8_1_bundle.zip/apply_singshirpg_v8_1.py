from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import py_compile
import shutil
import sys
import tempfile
from datetime import datetime
from pathlib import Path


PATCH_NAME = "appraisal-gem-affixes-v8.1"

READY_HASHES = {
    "life_system.py": "188d4eb8984ad6b1f7c1662a0aaf104d4f79bbafa08d3d1980773f4b8089bcc2",
    "character.py": "79120e98ca92377e3cc504d5fcafc54a9f2041c0d81fc2c40d9989da4df84ab0",
    "gem_manager.py": "d13f53600f7199306e04d86fbd71f87acd15fd87aeb432a01238121038fd1b2b",
    "artifact_overhaul_v5.py": "f88897a6e3bc4d4446ad0b31fb3b275bbf70300d7f1350dc3d236ea72aea3333",
    "artifact_manager.py": "107d376673a9ddd2fa3389ab7f1799c5d9b018a5873dd911403a0897c8991bd3",
    "info.py": "6ced9a68ddb0519447b820d8e55f5c32a468dac32b04d946efa8f09c82de646e",
}

DESIRED_HASHES = {
    "life_system.py": "dda014a6bb8da18bb6c2fd7fbefb168d6668821da04df79b94d12bace516d637",
    "character.py": "da4105af128f119f84c189f8e8197c5ad4f9aa390adff21bdd1a3472ef7eb778",
    "gem_manager.py": "e6c0d0c13c5bb9106eb452c4a6c7f859d75b64fdca0a59bd9ba89253107ec405",
    "artifact_overhaul_v5.py": "875323a29c8275000db3ab82397dca4d3b292ec44b213e4de399c7b880b47bfc",
    "artifact_manager.py": "3cb3de5b3b3d478589dec5505ff3326a0bbada1b4caadcf89fb99c12d76fc1bf",
    "info.py": "cbf9a8a7d24bc78a43f80474d0b4326326b2079b375804aa91f14d6c13064655",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_root(value: str | None) -> Path:
    candidates = [Path(value)] if value else []
    candidates.extend((Path.cwd(), Path(__file__).resolve().parent))
    for candidate in candidates:
        candidate = candidate.resolve()
        if (candidate / "main.py").is_file() and (candidate / "rpg_commands.py").is_file():
            return candidate
    raise SystemExit(
        '저장소 루트를 찾지 못했습니다. H:\\디코봇에서 실행하거나 '
        '--root "H:\\디코봇"을 지정하세요.'
    )


def payload_dir() -> Path:
    result = Path(__file__).resolve().parent / "payload"
    if not result.is_dir():
        raise SystemExit(f"payload 폴더가 없습니다: {result}")
    return result


def verify_payload() -> list[str]:
    errors = []
    for name, expected in DESIRED_HASHES.items():
        source = payload_dir() / name
        if not source.is_file():
            errors.append(f"{name}: payload 누락")
            continue
        if sha256(source) != expected:
            errors.append(f"{name}: payload 해시 불일치")
            continue
        try:
            py_compile.compile(str(source), doraise=True)
        except py_compile.PyCompileError as error:
            errors.append(f"{name}: 문법 검사 실패: {error.msg}")
    return errors


def inspect(root: Path):
    rows = []
    for name, desired in DESIRED_HASHES.items():
        target = root / name
        if not target.is_file():
            rows.append((name, "missing", None))
            continue
        current = sha256(target)
        if current == desired:
            status = "applied"
        elif current == READY_HASHES[name]:
            status = "ready"
        else:
            status = "conflict"
        rows.append((name, status, current))
    return rows


def print_status(root: Path) -> bool:
    errors = verify_payload()
    if errors:
        print("[payload 오류]")
        for error in errors:
            print(f"  - {error}")
        return False
    labels = {
        "ready": "적용 가능",
        "applied": "이미 적용됨",
        "missing": "파일 없음",
        "conflict": "충돌",
    }
    okay = True
    print(f"저장소: {root}")
    for name, status, current in inspect(root):
        print(f"  {name:<28} {labels[status]}")
        if status in {"missing", "conflict"}:
            okay = False
            if current:
                print(f"    현재 SHA256: {current}")
                print("    이 파일은 확인한 v8 기준 상태와 다릅니다.")
    if okay:
        print("\n파일·payload·문법 검사를 통과했습니다. DB는 변경하지 않았습니다.")
    return okay


def show_diff(root: Path) -> int:
    if not print_status(root):
        print("\n충돌 파일이 있어 미리보기를 중단했습니다.")
        return 2
    for name, status, _ in inspect(root):
        if status == "applied":
            continue
        old = (root / name).read_text(encoding="utf-8").splitlines(keepends=True)
        new = (payload_dir() / name).read_text(encoding="utf-8").splitlines(keepends=True)
        sys.stdout.writelines(
            difflib.unified_diff(old, new, fromfile=f"a/{name}", tofile=f"b/{name}")
        )
    return 0


def apply_patch(root: Path) -> int:
    if not print_status(root):
        print("\n아무 파일도 수정하지 않았습니다.")
        return 2
    pending = [name for name, status, _ in inspect(root) if status == "ready"]
    if not pending:
        print("\n모든 대상 파일이 이미 v8.1 상태입니다.")
        return 0

    backup_root = root / ".singshirpg_patch_backups" / PATCH_NAME
    backup_dir = backup_root / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_dir.mkdir(parents=True, exist_ok=False)
    for name in pending:
        shutil.copy2(root / name, backup_dir / name)

    state = {
        "patch": PATCH_NAME,
        "root": str(root),
        "backup_dir": str(backup_dir),
        "files": pending,
        "applied_hashes": {name: DESIRED_HASHES[name] for name in pending},
    }
    (backup_root / "latest.json").write_text(
        json.dumps(state, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    written = []
    try:
        for name in pending:
            target = root / name
            source = payload_dir() / name
            with tempfile.NamedTemporaryFile(
                mode="wb",
                delete=False,
                dir=target.parent,
                prefix=f".{name}.",
                suffix=".tmp",
            ) as handle:
                handle.write(source.read_bytes())
                temporary = Path(handle.name)
            temporary.replace(target)
            written.append(name)
        for name in pending:
            py_compile.compile(str(root / name), doraise=True)
            if sha256(root / name) != DESIRED_HASHES[name]:
                raise RuntimeError(f"{name} 적용 후 해시 불일치")
    except Exception as error:
        for name in written:
            shutil.copy2(backup_dir / name, root / name)
        print(f"\n적용 오류로 파일을 원상복구했습니다: {error}")
        return 3

    print(f"\n{len(pending)}개 파일에 v8.1 패치를 적용했습니다.")
    print(f"백업 위치: {backup_dir}")
    print("DB 스키마 변경은 없습니다. 봇을 완전히 재시작해주세요.")
    return 0


def revert_patch(root: Path) -> int:
    backup_root = root / ".singshirpg_patch_backups" / PATCH_NAME
    state_path = backup_root / "latest.json"
    if not state_path.is_file():
        print("복구 정보가 없습니다.")
        return 2
    state = json.loads(state_path.read_text(encoding="utf-8"))
    backup_dir = Path(state["backup_dir"])
    files = list(state["files"])
    conflicts = []
    for name in files:
        target = root / name
        if not target.is_file() or sha256(target) != DESIRED_HASHES[name]:
            conflicts.append(name)
    if conflicts:
        print("다음 파일이 적용 후 다시 변경되어 자동 복구를 중단합니다:")
        for name in conflicts:
            print(f"  - {name}")
        return 2
    for name in files:
        shutil.copy2(backup_dir / name, root / name)
    print(f"{len(files)}개 파일을 v8 상태로 복구했습니다.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="SingshiRPG v8.1 patch")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--diff", action="store_true")
    mode.add_argument("--apply", action="store_true")
    mode.add_argument("--revert", action="store_true")
    parser.add_argument("--root")
    args = parser.parse_args()
    root = resolve_root(args.root)
    if args.check:
        return 0 if print_status(root) else 2
    if args.diff:
        return show_diff(root)
    if args.apply:
        return apply_patch(root)
    return revert_patch(root)


if __name__ == "__main__":
    raise SystemExit(main())
